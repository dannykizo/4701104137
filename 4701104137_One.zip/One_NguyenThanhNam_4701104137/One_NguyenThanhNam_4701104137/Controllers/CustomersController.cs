﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CustomersController.Models; 

namespace CustomersController.Controllers
{
    public class CustomersController : Controller
    {
    
        private readonly YourDbContext _context;

        public CustomersController(YourDbContext context)
        {
            _context = context;
        }

        // Action cũ, không cần thay đổi
        public IActionResult Index()
        {
            return View();
        }

        // Action mới để lấy tất cả khách hàng
        public async Task<IActionResult> GetAll()
        {
            var customers = await _context.Customers
                                .OrderBy(c => c.IsYoungDriver) // Ưu tiên không phải tài xế trẻ
                                .ThenBy(c => c.BirthDate)      // Sau đó sắp xếp theo ngày sinh
                                .ToListAsync();

            return View(customers);
        }
    }
}
